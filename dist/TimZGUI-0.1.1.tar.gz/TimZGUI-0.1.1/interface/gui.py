from tkinter import *
from tkinter import ttk
from tkinter import font
from interface.db_manager import DBManager

HelpString = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
HEADER_ROW = 0
ROW_SIZE=0

class DataEntryGUI:
    def __init__(self, root, db):
        self.root = root
        self.db = db
        self.root.title("Main Control")

        self.mainframe = self.createMainFrame()

        self.help_button = HelpButton(root, self.mainframe)
        self.program_sel = SelBox(self, self.mainframe, self.db)
        self.new_button = CreateProgramButton(root, self.mainframe, self.db, self.program_sel)
        self.deleteButton = DeleteProgramButton(root, self.mainframe, self.program_sel, self.db)
        self.tableFrame = ttk.Frame(self.mainframe)

        self.createElements()

        self.segWindow = SegmentWindow(self.tableFrame, self.db, self.program_sel, self.mainframe, self.root)
        

        for child in self.mainframe.winfo_children(): 
            child.grid_configure(padx=5, pady=5)

        self.segWindow.canvas.wait_visibility()
        self.refreshAll()
        self.program_sel.refreshVals()

    def createMainFrame(self):
        mainframe = ttk.Frame(self.root, padding="3 3 12 12")
        mainframe.grid(column=0, row=0, sticky=(N,W,E,S))
        mainframe.configure(width=1280, height=800)
        mainframe.columnconfigure(0, weight=0, minsize=200)
        mainframe.columnconfigure(1, minsize=200)
        mainframe.columnconfigure(2, minsize=300, weight=4)
        mainframe.columnconfigure(3, minsize=200)
        mainframe.columnconfigure(4, minsize=200, weight=1)
        mainframe.rowconfigure(0, weight=1, minsize=80)
        mainframe.rowconfigure(1, weight=3, minsize=200)
        mainframe.rowconfigure(2, weight=1, minsize=80)

        return mainframe

    def createElements(self):
        mf = self.mainframe
        programFont = font.Font(family=font.nametofont('TkHeadingFont').actual()['family'], name='appProgramFont', size=20)
        ttk.Label(mf, text="Program:", font=programFont).grid(column=0, row=0, sticky=(E))

        # Place program selection box
        self.program_sel.container.grid(column=1, row=0, sticky=(W,E), columnspan=3)
        # Place program creation button
        self.new_button.btn.grid(column=4, row=0, sticky=(N,S,E,W))

        self.tableFrame.grid(column=0, columnspan=4, row=1, sticky=(N,S,E,W))

       
        self.deleteButton.btn.grid(column=3, row=2, sticky=(N,W,E,S))
        ttk.Button(mf, text="Start", command=self.runStart).grid(column=4, row=1, sticky=(N,S,E,W))

        # Place Help button
        self.help_button.button.grid(column=4, row=2, sticky=(N,S,W,E))


    def runStart(self):
        pass

    def refreshAll(self):
        self.deleteButton.refreshVals()
        self.segWindow.refreshVals()
        self.segWindow.FrameHeight()

class HelpButton:
    def __init__(self, root, frame):
        self.root = root
        self.button = ttk.Button(frame, text="Help", command=self.showHelp)
        self.help_str = StringVar()
        self.help_str.set(HelpString)

    def showHelp(self):
        help_dlg = Toplevel(self.root)
        help_dlg.title("Help")
        self.help_dlg = help_dlg
        ttk.Label(help_dlg, 
                  textvariable=self.help_str, 
                  wraplength=400, 
                  justify=LEFT).grid(column=0, columnspan=2, row=0)
        ttk.Button(help_dlg, text="Exit", command=self.closeHelp).grid(column=1, row=1, sticky=(N,S,E,W))
        help_dlg.rowconfigure(1,minsize=50)
        help_dlg.protocol("WM_DELETE_WINDOW", self.closeHelp)
        help_dlg.transient(self.root)
        self.root.eval(f'tk::PlaceWindow {str(help_dlg)} center')
        help_dlg.wait_visibility()
        help_dlg.grab_set()
        help_dlg.wait_window()

    def closeHelp(self):
        if(self.help_dlg):
            self.help_dlg.destroy()
        else:
            print("Error: Help dialog already destroyed")

class SelBox():
    def __init__(self, main, frame, db):
        self.program_str = StringVar()
        self.main = main
        self.db = db
        self.container = ttk.Frame(frame)
        program_sel = ttk.Combobox(self.container, textvariable=self.program_str)
        program_sel['values'] = [x[0] for x in db.getPrograms()]
        program_sel.state(["readonly"])
        program_sel.bind('<<ComboboxSelected>>', self.onChange)
        program_sel.grid(column=0, row=0, sticky=(N,S,E,W))
        self.container.columnconfigure(0, weight=1)
        self.container.rowconfigure(0, minsize=40)
        self.sel_box = program_sel

    def refreshVals(self):
        programs = [x[0] for x in self.db.getPrograms()]
        self.sel_box['values'] = programs
        if self.program_str.get() not in programs:
            if(len(programs) > 0):
                self.program_str.set(programs[0])
            else:
                self.setVal(None)
            self.onChange(None)

    def setVal(self, name):
        if(not name):
            self.program_str.set("")
        else:
            self.program_str.set(name)
        self.onChange(None)

    def onChange(self, arg):
        print("Program Now: " +self.program_str.get())
        self.main.refreshAll()

class CreateProgramButton():
    def __init__(self, root, frame, db, sel):
        self.root = root
        self.btn = ttk.Button(frame, text="Create New", command=self.addDialog)
        self.db = db
        self.sel = sel
        self.entry = None
    
    def addDialog(self):
        create_dlg = Toplevel(self.root)
        self.create_dlg = create_dlg
        create_dlg.title("Create Program")
        self.entry = StringVar()
        ttk.Label(create_dlg, 
                  text="Program Name:", 
                  wraplength=400, 
                  justify=LEFT).grid(column=0, row=0)
        ttk.Entry(create_dlg, textvariable=self.entry).grid(column=1, row=0, columnspan=3)
        ttk.Button(create_dlg, text="Cancel", command=self.closeDialog).grid(column=2, row=1, sticky=(N,S))
        ttk.Button(create_dlg, text="Enter", command=self.addProgram).grid(column=3, row=1, sticky=(N,S))
        create_dlg.rowconfigure(1, minsize=50)
        create_dlg.protocol("WM_DELETE_WINDOW", self.closeDialog)
        create_dlg.transient(self.root)
        self.root.eval(f'tk::PlaceWindow {str(create_dlg)} center')
        create_dlg.wait_visibility()
        create_dlg.grab_set()
        create_dlg.wait_window()

    def addProgram(self):
        name = self.entry.get()
        if(name):
            self.db.addProgram(name)
            self.sel.refreshVals()
            self.sel.setVal(name)
        else:
            print("Error: Name invalid or null")
        self.closeDialog()

    def closeDialog(self):
        if(self.create_dlg):
            self.create_dlg.destroy()
        else:
            print("Error: Creation dialog already destroyed")

class DeleteProgramButton():
    def __init__(self, root, frame, sel, db):
        self.btn = ttk.Button(frame, text="Delete Program", command=self.showDialog)
        self.root = root
        self.sel = sel
        self.db = db

    def refreshVals(self):
        programs = [x[0] for x in self.db.getPrograms()]
        if self.sel.program_str.get() not in programs:
            self.btn.state(["disabled"])
        else:
            self.btn.state(["!disabled"])

    def showDialog(self):
        del_dlg = Toplevel(self.root)
        self.del_dlg = del_dlg
        del_dlg.title("Delete Program")
        ttk.Label(del_dlg, 
                  text="Are you sure you would like to delete \"{}\"".format(self.sel.program_str.get()), 
                  wraplength=400, 
                  justify=LEFT).grid(column=0, row=0, columnspan=2)
        ttk.Button(del_dlg, text="Cancel", command=self.closeDialog).grid(column=0, row=1, sticky=(N,S))
        ttk.Button(del_dlg, text="Enter", command=self.deleteProgram).grid(column=1, row=1, sticky=(N,S))
        del_dlg.rowconfigure(1, minsize=50)
        del_dlg.protocol("WM_DELETE_WINDOW", self.closeDialog)
        del_dlg.transient(self.root)
        self.root.eval(f'tk::PlaceWindow {str(del_dlg)} center')
        del_dlg.wait_visibility()
        del_dlg.grab_set()
        del_dlg.wait_window()

    def deleteProgram(self):
        programs = [x[0] for x in self.db.getPrograms()]
        if self.sel.program_str.get() not in programs:
            print("Error: the selected program does not exist")
        else:
            self.db.deleteProgram(self.sel.program_str.get())
        self.sel.refreshVals()
        self.closeDialog()

    def closeDialog(self):
        if(self.del_dlg):
            self.del_dlg.destroy()
        else:
            print("Error: Delete dialog already destroyed")

class SegmentWindow():
    def __init__(self, parent, db, sel, mainframe, root):
        self.root = root
        self.AddButton = ttk.Button(mainframe, 
                   text="Add Segment", 
                   command=self.addSegment)
        self.AddButton.grid(column=0, row=2, sticky=(N,W,E,S)) 
        self.delmanager = SegDeletion(root, self, db)
        self.DelButton = ttk.Button(mainframe, 
                   text="Delete Segment", 
                   command=self.deleteSegment)
        self.DelButton.grid(column=1, row=2, sticky=(N,W,E,S))
        self.DelButton.state(['disabled'])

        self.db = db
        self.sel = sel
        v = ttk.Scrollbar(parent, orient=VERTICAL)
        self.canvas = Canvas(parent, yscrollcommand=v.set)
        self.canvas.grid(column=0, row=0, sticky=(N,S,E,W))
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=0, minsize=50)
        parent.rowconfigure(0, weight=1)
        v.grid(column=1, row=0, sticky=(N,S,E,W))
        v['command'] = self.canvas.yview
        self.segFrame = ttk.Frame(self.canvas)
        self.canvasFrame = self.canvas.create_window(0,0, anchor='nw', window=self.segFrame)
        self.canvas.bind('<Configure>', self.FrameWidth)

        # Configure table columns
        self.segFrame.columnconfigure(0, weight=0, minsize=50)
        self.segFrame.columnconfigure(1, weight=1, minsize=50)
        self.segFrame.columnconfigure(2, weight=1, minsize=50)
        self.segFrame.columnconfigure(3, weight=1, minsize=50)
        self.segFrame.columnconfigure(4, weight=1, minsize=50)
        self.segFrame.columnconfigure(5, weight=1, minsize=50)
        self.header = TableHeader(self.segFrame)
        self.segments = []
        
        programName = self.sel.program_str.get()
        self.pid = self.db.getProgramFromName(programName)
    
    def FrameHeight(self):
        if(len(self.segments) > 0):
            self.canvas.configure(scrollregion=(0,0,self.segFrame.winfo_width(), ((self.lastRow - 1) * (self.segments[0].EditBtn.winfo_height() + 10)) + self.header.transText.winfo_height() + 10))
            #self.canvas.configure(scrollregion=(0,0,self.segFrame.winfo_width(), (self.lastRow) * (self.segments[0].transText.winfo_height() + 10)))
            

    def FrameWidth(self, event):
        canvas_width = event.width
        self.canvas.itemconfig(self.canvasFrame, width = canvas_width)
        self.FrameHeight()
        
    
    def refreshVals(self):
        for x in self.segments:
            x.destroy()
        self.segments = []
        programName = self.sel.program_str.get()
        self.pid = self.db.getProgramFromName(programName)
        if(self.db.programValid(programName)):
            x = 0
            for segment in self.db.getSegFromName(programName):
                self.segments.append(TableRow(self.segFrame, x, segment, self))
                x += 1
            self.lastRow=x
            if(x>0):
                self.segments[0].EditBtn.wait_visibility()
        self.FrameHeight()

    def refreshSelection(self):
        selected = False
        for seg in self.segments:
            if(seg.checkvar):
                if(seg.checkvar.get() == "1"):
                    selected = True
        if(selected):
            self.DelButton.state(['!disabled'])
        else:
            self.DelButton.state(['disabled'])
        self.FrameHeight()

    def addSegment(self):
        self.segments.append(EditRow(self, self.segFrame, 
                                     self.lastRow, 
                                     self.db, 
                                     self.db.getProgramFromName(self.sel.program_str.get())))
        self.lastRow += 1
        self.FrameHeight()

    def deleteSegment(self):
        seg_list = []
        for seg in self.segments:
            if(seg.checkvar):
                if(seg.checkvar.get() == "1"):
                    seg_list.append(seg)
        if(len(seg_list) > 0):
            print(len(seg_list))
            self.delmanager.deleteSegment(seg_list)


class TableHeader():
    def __init__(self, parent):
        parent.rowconfigure(HEADER_ROW, minsize=ROW_SIZE)
        headerFont = font.Font(family=font.nametofont('TkHeadingFont').actual()['family'], name='appHeaderFont', size=18, weight='bold')
        self.transText = ttk.Label(parent, text="Trans (in)", font=headerFont)
        self.transText.grid(column=1, row=HEADER_ROW, ipadx=5, ipady=10)
        self.lengthText = ttk.Label(parent, text="Length (in)", font=headerFont)
        self.lengthText.grid(column=2, row=HEADER_ROW, padx=5, ipady=10)
        self.PPIText = ttk.Label(parent, text="PPI", font=headerFont)
        self.PPIText.grid(column=3, row=HEADER_ROW, ipadx=5, ipady=10)
        self.PauseText = ttk.Label(parent, text="Pause", font=headerFont)
        self.PauseText.grid(column=4, row=HEADER_ROW, ipadx=5, ipady=10)
        self.EditText = ttk.Label(parent, text="Edit", font=headerFont)
        self.EditText.grid(column=5, row=HEADER_ROW, ipadx=5, ipady=10)

class TableRow():
    def __init__(self, parent, row, seg, window):
        rowFont = font.Font(family=font.nametofont('TkDefaultFont').actual()['family'], name='appRowFont', size=16)
        self.window = window
        self.parent = parent
        self.row = row
        self.seg = seg
        self.checkvar = StringVar(value="0")
        self.check = ttk.Checkbutton(parent, variable=self.checkvar, onvalue="1", offvalue="0", command=window.refreshSelection)
        self.transText = ttk.Label(parent, text=str(seg[0]), font=rowFont)
        self.lengthText = ttk.Label(parent, text=str(seg[1]), font=rowFont)
        self.PPIText = ttk.Label(parent, text=str(seg[2]), font=rowFont)
        self.EditBtn = ttk.Button(parent, text="\u270D", command=self.edit)
        txt = ""
        if(seg[3] == 0):
            txt = "No"
        else:
            txt = "Yes"
        self.PauseText = ttk.Label(parent, text=txt, font=rowFont)
        self.items = [self.check, self.transText, self.lengthText, self.PPIText, self.PauseText, self.EditBtn]
        self.idn = int(seg[4])
        x = 0
        for i in self.items:
            i.grid(column=x, row=row+1, ipadx=5, ipady=10)
            x += 1
    
    def edit(self):
        self.window.segments.remove(self)
        self.destroy()
        self.window.segments.append(EditRow(self.window, 
                                            self.parent, 
                                            self.row, 
                                            self.window.db, 
                                            self.window.pid, 
                                            segment=self.seg))

    def destroy(self):
        for x in self.items:
            x.destroy()

class EditRow():
    def __init__(self, segwin, parent, row, db, pid,segment=None):
        self.window = segwin
        self.window.AddButton.state(['disabled'])
        self.edit = False
        self.db = db
        self.pid = pid
        self.trans = StringVar()
        self.length = StringVar()
        self.PPI = StringVar()
        self.Pause = StringVar(value="No")
        if(segment):
            self.segment=segment
            self.edit = True
            self.trans.set(segment[0])
            self.length.set(segment[1])
            self.PPI.set(segment[2])
            
        self.transEntry = ttk.Entry(parent, textvariable=self.trans)
        if(not db.segmentTrans0(pid)):
            self.trans.set("0")
            self.transEntry.state(["readonly", "disabled"])
        self.lengthEntry = ttk.Entry(parent, textvariable=self.length)
        self.PPIEntry = ttk.Entry(parent, textvariable=self.PPI)
        self.PauseEntry = ttk.Combobox(parent, textvariable=self.Pause)
        self.PauseEntry['values'] = ["Yes", "No"]
        self.PauseEntry.state(["readonly"])
        self.EditBtn = ttk.Button(parent, text="\u2713", command=self.confirm)
        self.window.root.bind('<Return>', lambda e: self.EditBtn.invoke())

        self.items = [self.transEntry, self.lengthEntry, self.PPIEntry, self.PauseEntry, self.EditBtn]
        x = 1
        for i in self.items:
            i.grid(column=x, row=row+1, ipadx=5, ipady=10)
            parent.rowconfigure(x, minsize=ROW_SIZE)
            x += 1

    def validateEntries(self):
        return True
    
    def confirm(self):
        if(self.validateEntries()):
            if(self.edit):
                pause = 0
                if(self.Pause.get() == "Yes"):
                    pause = 1
                try:
                    self.db.updateSegment((float(self.trans.get()), 
                                        float(self.length.get()), 
                                        int(self.PPI.get()), 
                                        pause,
                                        self.segment[4]))
                except ValueError:
                    print("Error, segment values incorrect")
            else:
                pause = 0
                if(self.Pause.get() == "Yes"):
                    pause = 1
                try:
                    self.db.addSegment((self.pid, 
                                        float(self.trans.get()), 
                                        float(self.length.get()), 
                                        int(self.PPI.get()), 
                                        pause))
                except ValueError:
                    print("Error, segment values incorrect")
            self.destroy()
            self.window.refreshVals()
    
    def destroy(self):
        self.window.root.unbind_all('<Return>')
        for x in self.items:
            x.destroy()
        self.window.AddButton.state(['!disabled'])

class SegDeletion():
    def __init__(self, root, window, db):
        self.seg_list = []
        self.root = root
        self.db = db
        self.window = window

    def deleteSegment(self, seg_list):
        self.seg_list = seg_list
        segn = len(seg_list)
        if(segn == 0):
            print("Error, no segments selected")
            return
        else:
            del_dlg = Toplevel(self.root)
            self.del_dlg = del_dlg
            del_dlg.title("Delete Program")
            ttk.Label(del_dlg, 
                    text="Are you sure you would like to delete {} segment(s)?".format(segn), 
                    wraplength=400, 
                    justify=LEFT).grid(column=0, row=0, columnspan=2)
            ttk.Button(del_dlg, text="Cancel", command=self.closeDialog).grid(column=0, row=1, sticky=(N,S))
            ttk.Button(del_dlg, text="Yes", command=self.delete).grid(column=1, row=1, sticky=(N,S))
            del_dlg.rowconfigure(1, minsize=50)
            del_dlg.protocol("WM_DELETE_WINDOW", self.closeDialog)
            del_dlg.transient(self.root)
            self.root.eval(f'tk::PlaceWindow {str(del_dlg)} center')
            del_dlg.wait_visibility()
            del_dlg.grab_set()
            del_dlg.wait_window()

    def delete(self):
        self.db.deleteSegments([x.idn for x in self.seg_list])
        self.closeDialog()
        self.window.refreshVals()

    def closeDialog(self):
        if(self.del_dlg):
            self.del_dlg.destroy()
        else:
            print("Error: Delete dialog already destroyed")

def run():
    # Create the main window
    root = Tk()
    root.columnconfigure(0, weight=1)
    root.rowconfigure(0, weight=1)

    s = ttk.Style()
    print(s.lookup('TButton', 'font'))
    buttonFont = font.Font(family=font.nametofont('TkDefaultFont').actual()['family'], name='appButtonFont', size=18)
    s.configure('TButton', font=buttonFont)
    s.configure('TCombobox', font=buttonFont, arrowsize=20)
    root.option_add("*TCombobox*Listbox*Font", buttonFont)

    # Create an instance of the database manager
    dbm = DBManager()
    # Create an instance of the DataEntryGUI class
    app = DataEntryGUI(root, dbm)
    
    # Run the GUI application
    root.mainloop()
    
if __name__ == '__main__': 
    run()