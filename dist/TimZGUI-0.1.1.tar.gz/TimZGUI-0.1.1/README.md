TODO:

- Row edits
- Input Validation
    - Program Input
    - Segment Input
    - Enforce first element 0
- Scrolling/Window adjustment
- Themeing/Styling